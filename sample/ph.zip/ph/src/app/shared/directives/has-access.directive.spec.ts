import { HasAccessDirective } from './has-access.directive';

describe('HasAccessDirective', () => {
  it('should create an instance', () => {
    const directive = new HasAccessDirective();
    expect(directive).toBeTruthy();
  });
});
