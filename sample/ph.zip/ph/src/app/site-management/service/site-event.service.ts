import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class SiteEventService {

  siteApiEvent = new Subject<any>();
   constructor() { }

}
