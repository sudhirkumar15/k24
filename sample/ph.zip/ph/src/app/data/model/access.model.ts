export interface AccessModel {
    group: string;
    resource: string;
    operation: string;
}
