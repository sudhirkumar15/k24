export class DropDownModel {
    name: string;
    id: number;
}
