export interface ContextMenuModel {
    actionCode: string;
    actionLabel: string;
    isBulkAction: boolean;
}
