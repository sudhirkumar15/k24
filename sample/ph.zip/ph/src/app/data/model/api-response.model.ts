export interface ApiResponseModel {
    status: number;
    error: Object;
    data: Object;

}
