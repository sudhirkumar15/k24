export class PaginationModel {
    isFirst: boolean;
    isLast: boolean;
    pageNumber: number;
    totalCount: number;
    totalPages: number;
    pageSize: number;
}
