import { Injectable } from '@angular/core';

@Injectable()
export class RightSidePanelService {
  selectedRow: any;
  selectedTabIndex: number;
  constructor() { }

}
