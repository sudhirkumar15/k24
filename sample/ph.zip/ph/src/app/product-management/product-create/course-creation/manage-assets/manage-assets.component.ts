import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-course-manage-assets',
  templateUrl: './manage-assets.component.html',
  styleUrls: ['./manage-assets.component.scss']
})
export class ManageAssetsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
