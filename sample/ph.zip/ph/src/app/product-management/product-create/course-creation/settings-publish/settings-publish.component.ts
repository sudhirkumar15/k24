import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-course-settings',
  templateUrl: './settings-publish.component.html',
  styleUrls: ['./settings-publish.component.scss']
})
export class SettingsPublishComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
