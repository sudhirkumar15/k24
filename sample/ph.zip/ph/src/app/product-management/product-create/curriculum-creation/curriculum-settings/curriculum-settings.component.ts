import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-curriculum-settings',
  templateUrl: './curriculum-settings.component.html',
  styleUrls: ['./curriculum-settings.component.scss']
})
export class CurriculumSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
