export const environment = {
  production: true,
  theme: 'Earth',
  language: 'en.json'
};
